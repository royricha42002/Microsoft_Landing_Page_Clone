/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["*"],
  theme: {
    extend: {
      width:{
        '45%': '45%'
      }
    },
  },

  plugins: [],
}

